package ynjh.company.controller.discuss;

public class CompanyDiscussController {

}
