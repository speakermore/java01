package ynjh.company.controller.companyinformation;

public class CompanyCommentArticleController {

}
