package ynjh.company.service.impl.discuss;

import java.util.List;
import ynjh.company.service.CompanyDiscussService;
import ynjh.personal.entity.Discuss;

public class CompanyDiscussServiceImpl implements CompanyDiscussService{

	@Override
	public int addDiscuss(Discuss discuss) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Discuss> findAll(Integer page) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Discuss findById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateStatus(Integer id) {
		// TODO Auto-generated method stub
		return 0;
	}

}
