package ynjh.company.service.impl.companyinformation;

import java.util.List;

import ynjh.company.service.CompanyCommentArticleService;
import ynjh.personal.entity.CommentArticle;

public class CompanyCommentArticleIServicempl implements CompanyCommentArticleService{

	@Override
	public int addArticle(CommentArticle comArt) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<CommentArticle> findAll(Integer page) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CommentArticle findById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateStatus(Integer id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateLike(Integer id) {
		// TODO Auto-generated method stub
		return 0;
	}

}
