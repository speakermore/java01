package ynjh.company.dao.company;

public interface CompanyFollowMapper {
	public Integer updateFollow(Integer followId ,Integer ByFollowId);
}
