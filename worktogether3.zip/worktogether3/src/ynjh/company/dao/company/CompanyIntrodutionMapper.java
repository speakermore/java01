package ynjh.company.dao.company;

import ynjh.company.entity.Company;

public interface CompanyIntrodutionMapper {
	public Integer updateCompanyInt(Company company);
}
