package ynjh.company.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class CompanyTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
