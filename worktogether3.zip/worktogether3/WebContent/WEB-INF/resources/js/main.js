var displayDiv=function(id){
	$(id).css("display","block");
};

var hiddenDiv=function(id){
	$(id).css("display","none");
}
